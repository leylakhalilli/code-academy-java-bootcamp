import java.math.BigDecimal;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        double kom = 0;
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Enter amount:");
//        int amount = scanner.nextInt();
//
////        if ( amount < 100) {
//////            System.out.print("kom=" + kom);
////            amount=100;
////
////        }
//        if (amount > 100) {
//            kom += (amount - 100) * 0.05;
////            System.out.print("kom=" + kom);
//            amount = 100;
//        }
//        if (amount > 500) {
//            kom += (amount - 500) * 0.07;
//            amount = 500;
////            System.out.print("kom=" + kom);
//        }
//        if (amount > 1000) {
//            kom += (amount - 1000) * 0.1;
//            amount = 1000;
////            System.out.print("kom=" + kom);
//        }
//        System.out.print("kom=" + kom);




//        int number = 23415;
//        int newNumber = 0;
//        int c = 0;
//        c = number % 10000;
//        number /= 10000;
//        newNumber = c * 10 + number;
//        System.out.println(newNumber);

//        Scanner scanner = new Scanner(System.in);
//        System.out.print("amount=");
//        int amount = scanner.nextInt();
//
//        boolean cardType = false;//kredit
//        boolean internet = true;//yes
//        int balans = 1000;
//        double maxAmount = 500;
//
//        if (internet) {
//            if (maxAmount>amount) {
//                if (cardType) {
//                    System.out.print("pul cixdi.Balans=" + (balans - amount));
//                } else {
//                    if (balans > amount) {
//                        System.out.println("Debit kart-pul cixdi.Balans=" + (balans - amount));
//                    } else {
//                        System.out.println(" Debit kart Icaze yoxdu");
//
//                    }
//                }
//            } else {
//                System.out.println("Max meblegi kecdiniz");
//
//            }
//        }


    }
}
